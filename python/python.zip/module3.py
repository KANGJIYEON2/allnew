from minimum import min

a = input('Input First number : ')
b = input('Input Second number : ')

print(f'Min number is {min(a, b)}')