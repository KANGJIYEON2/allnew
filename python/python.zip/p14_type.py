arr = [1, 2, 3, 4]

print(id(arr))

print(type(arr))

print(type(10))

print(type([1, 2]))

print(type(type(10)))