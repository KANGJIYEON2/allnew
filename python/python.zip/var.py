#!/usr/bin/env python


n = 1
name = 'Kim'
n = n + 2
value = 1.2 * n
print("%f is 1.2 * %d" % (value, n))