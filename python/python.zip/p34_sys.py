import sys

sys.stdout.write("Enter your name : ")
name = sys.stdin.readline()
print(name)

gender = input("Enter your Gender : ")
print(gender)