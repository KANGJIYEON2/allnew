for i in [0, 1, 2, 3, 4]:
    print(f'{i} ^ 2 = {i*i}')
