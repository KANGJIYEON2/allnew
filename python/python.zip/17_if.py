a = int(input("Input the First Number : "))
b = int(input("Input the Second Number : "))

if a > b:
    print("Max is %d" % a )
else:
    print("Max is %d " % b)
