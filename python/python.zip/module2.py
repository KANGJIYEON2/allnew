import minimum as Min

a = input('Input First number : ')
b = input('Input Second number : ')

print(f'Min n3umber is {Min.min(a, b)}')