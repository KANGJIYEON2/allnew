import random
data = random.sample(range(1, 101), 10)
print(data)
print(f'Max value is : {findMax(data)}')
