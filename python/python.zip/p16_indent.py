n = 0

while True :
    n += 1

    if n > 10 :
        break
    if ((n % 2) == 0) :
        print(n)

