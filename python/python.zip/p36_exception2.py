a = "Hello"
b = 1

try:
    c = a + b
    print(c)
except:
    print('The Error is occurred')
finally:
    print(a)