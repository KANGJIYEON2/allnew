for in range(5):
    print(f'{i} ^ 2 = {i * i}')

for in range(1, 6):
    print(f'{i} ^ 2 = {i * i}')