import minimum

a = input('Input First number : ')
b = input('Input Second number : ')

print(f'Min number is {minimum.min(a, b)}')