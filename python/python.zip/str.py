#!/usr/bin/env python

a =  "Hello world"
print(a[0])
print(a[5:8])
print(a[:2])
print(a[-2])
print(a * 2)

b = " Good bye"
print(a + b)