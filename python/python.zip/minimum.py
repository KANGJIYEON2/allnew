def min(a, b):
    if a > b:
        return b
    else:
        return a