name = input("input name : ")
age = int(input("input age : "))

print("name : {}".format(name))
print("age : {}" .format(age))
