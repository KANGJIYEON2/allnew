import numpy as np

print(np.zeros(3))

arrZeros = np.zeros((2, 2))
print(arrZeros)

array2 = np.ones((3, 2))
print(array2)

