name = input("input name : ")
age = int(input("input age : "))

print("name : %s" % (name))
print("age : %d" % (age))
